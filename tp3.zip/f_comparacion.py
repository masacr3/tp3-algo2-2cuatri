def f_cmp_heap(vuelo1,vuelo2):
	tiempo1 = vuelo1[1]
	tiempo2 = vuelo2[1]
	return (tiempo1>tiempo2)-(tiempo1<tiempo2)
